I would like to thank every one making this possible.
People making Blender better every day.
Special thank to
Donators
People of xxx

For kindness, support, inspiration, testing, reporting errors and general help. meta-androcto, lijenstina, linda_bliblubli, Tynkatopi, nBurn, bzztploink, mirlip, gidio
People of xxx

Working to provide a dedicated material library.

Hope i don't forget anyone involved in the effort, if so, don't take offence and drop me a line.
